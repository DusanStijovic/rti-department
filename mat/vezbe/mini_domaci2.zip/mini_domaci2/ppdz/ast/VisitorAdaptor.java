// generated with ast extension for cup
// version 0.8
// 16/10/2017 12:42:35


package ppdz.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(Rhs rhs) { }
    public void visit(Statement statement) { }
    public void visit(Var_list var_list) { }
    public void visit(Factor_list factor_list) { }
    public void visit(Local_var_list local_var_list) { }
    public void visit(Parameter parameter) { }
    public void visit(Declaration_part declaration_part) { }
    public void visit(Ident_expr_list ident_expr_list) { }
    public void visit(Stmt_list stmt_list) { }
    public void visit(Addop addop) { }
    public void visit(Declaration_list declaration_list) { }
    public void visit(Factor factor) { }
    public void visit(Term_list term_list) { }
    public void visit(Expr_list expr_list) { }
    public void visit(Parameter_list parameter_list) { }
    public void visit(Method_declaration_list method_declaration_list) { }
    public void visit(Mulop mulop) { }
    public void visit(Form_pars form_pars) { }
    public void visit(Return_type_ident return_type_ident) { }
    public void visit(Var_part var_part) { }
    public void visit(ParenthesisExpr ParenthesisExpr) { visit(); }
    public void visit(OperatorNew OperatorNew) { visit(); }
    public void visit(CharRef CharRef) { visit(); }
    public void visit(IntRef IntRef) { visit(); }
    public void visit(ArrayRef ArrayRef) { visit(); }
    public void visit(VarRef VarRef) { visit(); }
    public void visit(FuncCall FuncCall) { visit(); }
    public void visit(MinusFactor MinusFactor) { visit(); }
    public void visit(SimpleFactor SimpleFactor) { visit(); }
    public void visit(MulopFactor MulopFactor) { visit(); }
    public void visit(Term Term) { visit(); }
    public void visit(TermExpr TermExpr) { visit(); }
    public void visit(AddExpr AddExpr) { visit(); }
    public void visit(Expr Expr) { visit(); }
    public void visit(Expression Expression) { visit(); }
    public void visit(Expressions Expressions) { visit(); }
    public void visit(Act_pars Act_pars) { visit(); }
    public void visit(DivOp DivOp) { visit(); }
    public void visit(TimesOp TimesOp) { visit(); }
    public void visit(MinusOp MinusOp) { visit(); }
    public void visit(PlusOp PlusOp) { visit(); }
    public void visit(SimpleDesignator SimpleDesignator) { visit(); }
    public void visit(ArrayDesignator ArrayDesignator) { visit(); }
    public void visit(Designator Designator) { visit(); }
    public void visit(Print Print) { visit(); }
    public void visit(Return Return) { visit(); }
    public void visit(ReturnNoExpr ReturnNoExpr) { visit(); }
    public void visit(FuncCallStatement FuncCallStatement) { visit(); }
    public void visit(ProcCallStatement ProcCallStatement) { visit(); }
    public void visit(Assignment Assignment) { visit(); }
    public void visit(NoStatements NoStatements) { visit(); }
    public void visit(Statements Statements) { visit(); }
    public void visit(ArrayParameter ArrayParameter) { visit(); }
    public void visit(ScalarParameter ScalarParameter) { visit(); }
    public void visit(FormalParameter FormalParameter) { visit(); }
    public void visit(FormalParameters FormalParameters) { visit(); }
    public void visit(NoFormalParams NoFormalParams) { visit(); }
    public void visit(FormalParams FormalParams) { visit(); }
    public void visit(Method_dec Method_dec) { visit(); }
    public void visit(VoidRetType VoidRetType) { visit(); }
    public void visit(ReturnType ReturnType) { visit(); }
    public void visit(NoMethods NoMethods) { visit(); }
    public void visit(Methods Methods) { visit(); }
    public void visit(NoLocalVars NoLocalVars) { visit(); }
    public void visit(LocalVars LocalVars) { visit(); }
    public void visit(VarArrayId VarArrayId) { visit(); }
    public void visit(VarId VarId) { visit(); }
    public void visit(VarOrArrayId VarOrArrayId) { visit(); }
    public void visit(VarIdList VarIdList) { visit(); }
    public void visit(Var_dec Var_dec) { visit(); }
    public void visit(CharInitializer CharInitializer) { visit(); }
    public void visit(IntInitializer IntInitializer) { visit(); }
    public void visit(Type Type) { visit(); }
    public void visit(Const_dec Const_dec) { visit(); }
    public void visit(VarDeclaration VarDeclaration) { visit(); }
    public void visit(ConstDeclaration ConstDeclaration) { visit(); }
    public void visit(NoDeclarations NoDeclarations) { visit(); }
    public void visit(Declarations Declarations) { visit(); }
    public void visit(Prog_id Prog_id) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
