// generated with ast extension for cup
// version 0.8
// 16/10/2017 12:42:35


package ppdz.ast;

public class Statements extends Stmt_list {

    private Stmt_list stmt_list;
    private Statement statement;

    public Statements (Stmt_list stmt_list, Statement statement) {
        this.stmt_list=stmt_list;
        if(stmt_list!=null) stmt_list.setParent(this);
        this.statement=statement;
        if(statement!=null) statement.setParent(this);
    }

    public Stmt_list getStmt_list() {
        return stmt_list;
    }

    public void setStmt_list(Stmt_list stmt_list) {
        this.stmt_list=stmt_list;
    }

    public Statement getStatement() {
        return statement;
    }

    public void setStatement(Statement statement) {
        this.statement=statement;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(stmt_list!=null) stmt_list.accept(visitor);
        if(statement!=null) statement.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(stmt_list!=null) stmt_list.traverseTopDown(visitor);
        if(statement!=null) statement.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(stmt_list!=null) stmt_list.traverseBottomUp(visitor);
        if(statement!=null) statement.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Statements(\n");

        if(stmt_list!=null)
            buffer.append(stmt_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(statement!=null)
            buffer.append(statement.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Statements]");
        return buffer.toString();
    }
}
