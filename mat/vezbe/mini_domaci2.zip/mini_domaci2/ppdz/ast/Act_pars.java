// generated with ast extension for cup
// version 0.8
// 16/10/2017 12:42:35


package ppdz.ast;

public class Act_pars implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private Expr_list expr_list;

    public Act_pars (Expr_list expr_list) {
        this.expr_list=expr_list;
        if(expr_list!=null) expr_list.setParent(this);
    }

    public Expr_list getExpr_list() {
        return expr_list;
    }

    public void setExpr_list(Expr_list expr_list) {
        this.expr_list=expr_list;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(expr_list!=null) expr_list.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(expr_list!=null) expr_list.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(expr_list!=null) expr_list.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Act_pars(\n");

        if(expr_list!=null)
            buffer.append(expr_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Act_pars]");
        return buffer.toString();
    }
}
