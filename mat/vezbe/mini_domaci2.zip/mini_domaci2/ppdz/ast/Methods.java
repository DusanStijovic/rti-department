// generated with ast extension for cup
// version 0.8
// 16/10/2017 12:42:35


package ppdz.ast;

public class Methods extends Method_declaration_list {

    private Method_declaration_list method_declaration_list;
    private Method_dec method_dec;

    public Methods (Method_declaration_list method_declaration_list, Method_dec method_dec) {
        this.method_declaration_list=method_declaration_list;
        if(method_declaration_list!=null) method_declaration_list.setParent(this);
        this.method_dec=method_dec;
        if(method_dec!=null) method_dec.setParent(this);
    }

    public Method_declaration_list getMethod_declaration_list() {
        return method_declaration_list;
    }

    public void setMethod_declaration_list(Method_declaration_list method_declaration_list) {
        this.method_declaration_list=method_declaration_list;
    }

    public Method_dec getMethod_dec() {
        return method_dec;
    }

    public void setMethod_dec(Method_dec method_dec) {
        this.method_dec=method_dec;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(method_declaration_list!=null) method_declaration_list.accept(visitor);
        if(method_dec!=null) method_dec.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(method_declaration_list!=null) method_declaration_list.traverseTopDown(visitor);
        if(method_dec!=null) method_dec.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(method_declaration_list!=null) method_declaration_list.traverseBottomUp(visitor);
        if(method_dec!=null) method_dec.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Methods(\n");

        if(method_declaration_list!=null)
            buffer.append(method_declaration_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(method_dec!=null)
            buffer.append(method_dec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Methods]");
        return buffer.toString();
    }
}
