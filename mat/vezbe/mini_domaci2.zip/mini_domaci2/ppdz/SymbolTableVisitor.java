package ppdz;
import ppdz.ast.*;

public class SymbolTableVisitor extends VisitorAdaptor {

    public void report_error(String message) {
      System.err.print(message);
      System.err.println("");
      System.err.flush();
    }

/*****************************************************************
* Sledece tri promenljive ce biti vidljive iz svih
* visitor metoda. var_type sluzi za cuvanje cvora Struct koji 
* odgovara tipu na pocetku deklaracije grupe promenljivih.
* isVoid je logicka promenljiva koja ima vrednost true ako
* je povratni tip metode void. returnExists je logicka 
* promenljiva koja ima vrednost true ako metoda ima 
* return iskaz.
*****************************************************************/ 
        private Struct var_type=Tab.noType;
        private boolean isVoid=false, returnExists=false;

/*****************************************************************
* obj predstavlja Obj cvor glavne klase. Na kraju analize programa
* se unutrasnji opseg zatvara, a njegovi cvorovi vezuju za
* cvor glavne klase, tj. programa. 
*****************************************************************/ 
	public void visit(Program program) {
		program.getProg_id().obj.locals=Tab.topScope.locals;
		Tab.closeScope();
	}

/*****************************************************************
* Kada prepoznamo glavni program, u tabelu simbola ubacujemo 
* cvor koji mu odgovara i otvaramo novi opseg u koji cemo ubacivati 
* simbole glavnog programa.
*****************************************************************/ 
	public void visit(Prog_id prog_id) {
		prog_id.obj = Tab.insert(Obj.Prog,prog_id.getId(),prog_id.getLine(),Tab.noType);
                Tab.openScope();
	}

/*****************************************************************
* Kada se u obilasku stabla naidje na identifikator tipa,
* neterminalu type se dodeljuje odgovarajuci Struct cvor
* pronadjen prema imenu u tabeli simbola
* Da bi nam i pri obilasku cvorova VarId i VarArrayId bio dostupan
* tip promenljivih koje se deklarisu, sacuvacemo ga u 
* promenljivoj var_type.
*****************************************************************/ 
	public void visit(Type type) { 
		Obj novi=Tab.find(type.getId(), type.getLine());
                if (novi.kind == Obj.Type )
                   var_type = type.struct = novi.type;
                else {
                   report_error("Greska u liniji "+type.getLine()+" ("+type.getId()+") nije tip");
                   var_type = type.struct = Tab.noType;
               }
	}

/*****************************************************************
* Kada u deklaraciji dodjemo do imena pojedinacne promenljive,
* ubacujemo je u tabelu simbola (cak i kada je tip noType, da bismo u
* oporavku izbegli greske nedeklarisane promenljive)
*****************************************************************/ 
	public void visit(VarId varId) { 
		Tab.insert(Obj.Var, varId.getId(), varId.getLine(), var_type); 
	}

	public void visit(VarArrayId varArrayId) {
		Tab.insert(Obj.Var, varArrayId.getId(), varArrayId.getLine(), new Struct(Struct.Arr, var_type));  
	}

	public void visit(ReturnType returnType) {
		Struct t = returnType.getType().struct; 
		isVoid = (t == Tab.noType );
		returnType.obj = Tab.insert( Obj.Meth, returnType.getId(), returnType.getLine(), t); 
                Tab.openScope(); 
	}

	public void visit(VoidRetType voidRetType) {
		isVoid=true; 
		voidRetType.obj = Tab.insert( Obj.Meth, voidRetType.getId(), voidRetType.getLine(), Tab.noType); 
                Tab.openScope();		 
	}

/*****************************************************************
* Na kraju obrade metoda proveravamo da li se radi o metodu
* koji nije void, a u njegovom telu nema return iskaza. 
* Ako je to slucaj, prijavljuje se greska.
*****************************************************************/ 
	public void visit(Method_dec method_dec) {
		if (!isVoid && !returnExists) { 
			report_error("Greska u liniji "+method_dec.getLine()+": Metod mora imati return iskaz jer nije deklarisan sa void");
		}
                returnExists=false;
		Obj o = method_dec.getReturn_type_ident().obj;
                o.level=0; o.locals = Tab.topScope.locals; Tab.closeScope();

	}

/*****************************************************************
* Pri prepoznavanju return iskaza postavljamo promenljivu 
* returnExists. Ako metoda koja nije void ima prazan return 
* iskaz, prijavljuje se greska. Ako void metoda ima return 
* iskaz koji vraca vrednost, prijavljuje se greska.
*****************************************************************/
	public void visit(ReturnNoExpr returnNoExpr) { 
	        returnExists=true;
		if (!isVoid) {
			report_error("Greska u liniji "
                         +returnNoExpr.getLine()+": metod mora imati return iskaz sa izrazom jer nije deklarisan sa void");
		}
	}

	public void visit(Return ret) {
	        returnExists=true;
		if (isVoid) {
			report_error("Greska u liniji "+ret.getLine()+": metod ne sme imati return sa izrazom jer je deklarisan sa void");
		}
	}

/*****************************************************************
* Kada u telu metode detektujemo koriscenje nekog imena, 
* upotrebom metode find, proveravamo da li se objekat koji 
* odgovara tom imenu nalazi u tabeli simbola. Ako se ne nalazi
* prijavljujemo gresku. Ako se radi o koriscenju niza, moramo 
* proveriti i da li je objekat u tabeli simbola tipa niza.
*****************************************************************/ 
	public void visit(ArrayDesignator arrayDesignator) {
		Obj id = arrayDesignator.getIdent_expr_list().obj;
		if (id.type.kind!=Struct.Arr) {
                         report_error("Greska u liniji "+arrayDesignator.getLine()+": Ocekivan niz");
		}
                arrayDesignator.obj = id;	
	}

	public void visit(SimpleDesignator simpleDesignator) {
		Obj ob=Tab.find(simpleDesignator.getId(), simpleDesignator.getLine()); // find prijavljuje gresku u slucaju da ne nadje
                if (ob != Tab.noObj) {
                         System.out.println("Pretraga "+simpleDesignator.getLine()+" ("+simpleDesignator.getId()+"), nadjeno "+ob);
		} 
                simpleDesignator.obj = ob;
	}
}
