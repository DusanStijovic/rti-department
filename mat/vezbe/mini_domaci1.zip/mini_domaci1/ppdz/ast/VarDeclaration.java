// generated with ast extension for cup
// version 0.8
// 5/10/2017 8:30:6


package ppdz.ast;

public class VarDeclaration extends Declaration_part {

    private Var_dec var_dec;

    public VarDeclaration (Var_dec var_dec) {
        this.var_dec=var_dec;
        if(var_dec!=null) var_dec.setParent(this);
    }

    public Var_dec getVar_dec() {
        return var_dec;
    }

    public void setVar_dec(Var_dec var_dec) {
        this.var_dec=var_dec;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(var_dec!=null) var_dec.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(var_dec!=null) var_dec.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(var_dec!=null) var_dec.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclaration(\n");

        if(var_dec!=null)
            buffer.append(var_dec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclaration]");
        return buffer.toString();
    }
}
