// generated with ast extension for cup
// version 0.8
// 5/10/2017 8:30:6


package ppdz.ast;

public class FormalParameters extends Parameter_list {

    private Parameter_list parameter_list;
    private Parameter parameter;

    public FormalParameters (Parameter_list parameter_list, Parameter parameter) {
        this.parameter_list=parameter_list;
        if(parameter_list!=null) parameter_list.setParent(this);
        this.parameter=parameter;
        if(parameter!=null) parameter.setParent(this);
    }

    public Parameter_list getParameter_list() {
        return parameter_list;
    }

    public void setParameter_list(Parameter_list parameter_list) {
        this.parameter_list=parameter_list;
    }

    public Parameter getParameter() {
        return parameter;
    }

    public void setParameter(Parameter parameter) {
        this.parameter=parameter;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(parameter_list!=null) parameter_list.accept(visitor);
        if(parameter!=null) parameter.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(parameter_list!=null) parameter_list.traverseTopDown(visitor);
        if(parameter!=null) parameter.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(parameter_list!=null) parameter_list.traverseBottomUp(visitor);
        if(parameter!=null) parameter.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("FormalParameters(\n");

        if(parameter_list!=null)
            buffer.append(parameter_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(parameter!=null)
            buffer.append(parameter.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [FormalParameters]");
        return buffer.toString();
    }
}
