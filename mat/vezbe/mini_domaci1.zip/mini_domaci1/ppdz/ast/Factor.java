// generated with ast extension for cup
// version 0.8
// 5/10/2017 8:30:6


package ppdz.ast;

public abstract class Factor implements SyntaxNode {

    private SyntaxNode parent;

    private int line;

    public Designator getDesignator() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setDesignator(Designator designator) {
        throw new ClassCastException("tried to call abstract method");
    }

    public Act_pars getAct_pars() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setAct_pars(Act_pars act_pars) {
        throw new ClassCastException("tried to call abstract method");
    }

    public int getI() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setI(int i) {
        throw new ClassCastException("tried to call abstract method");
    }

    public char getC() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setC(char c) {
        throw new ClassCastException("tried to call abstract method");
    }

    public Type getType() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setType(Type type) {
        throw new ClassCastException("tried to call abstract method");
    }

    public Expr getExpr() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setExpr(Expr expr) {
        throw new ClassCastException("tried to call abstract method");
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public abstract void accept(Visitor visitor);
    public abstract void childrenAccept(Visitor visitor);
    public abstract void traverseTopDown(Visitor visitor);
    public abstract void traverseBottomUp(Visitor visitor);

    public String toString() { return toString(""); }
    public abstract String toString(String tab);
}
