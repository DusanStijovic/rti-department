// generated with ast extension for cup
// version 0.8
// 5/10/2017 8:30:6


package ppdz.ast;

public class NoDeclarations extends Declaration_list {

    public NoDeclarations () {
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("NoDeclarations(\n");

        buffer.append(tab);
        buffer.append(") [NoDeclarations]");
        return buffer.toString();
    }
}
