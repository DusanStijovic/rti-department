// generated with ast extension for cup
// version 0.8
// 5/10/2017 8:30:7


package ppdz.ast;

public abstract class Term_list implements SyntaxNode {

    private SyntaxNode parent;

    private int line;

    public Term_list getTerm_list() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setTerm_list(Term_list term_list) {
        throw new ClassCastException("tried to call abstract method");
    }

    public Addop getAddop() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setAddop(Addop addop) {
        throw new ClassCastException("tried to call abstract method");
    }

    public Term getTerm() {
        throw new ClassCastException("tried to call abstract method");
    }

    public void setTerm(Term term) {
        throw new ClassCastException("tried to call abstract method");
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public abstract void accept(Visitor visitor);
    public abstract void childrenAccept(Visitor visitor);
    public abstract void traverseTopDown(Visitor visitor);
    public abstract void traverseBottomUp(Visitor visitor);

    public String toString() { return toString(""); }
    public abstract String toString(String tab);
}
