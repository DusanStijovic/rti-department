// generated with ast extension for cup
// version 0.8
// 5/10/2017 8:30:6


package ppdz.ast;

public class FormalParams extends Form_pars {

    private Parameter_list parameter_list;

    public FormalParams (Parameter_list parameter_list) {
        this.parameter_list=parameter_list;
        if(parameter_list!=null) parameter_list.setParent(this);
    }

    public Parameter_list getParameter_list() {
        return parameter_list;
    }

    public void setParameter_list(Parameter_list parameter_list) {
        this.parameter_list=parameter_list;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(parameter_list!=null) parameter_list.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(parameter_list!=null) parameter_list.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(parameter_list!=null) parameter_list.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("FormalParams(\n");

        if(parameter_list!=null)
            buffer.append(parameter_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [FormalParams]");
        return buffer.toString();
    }
}
