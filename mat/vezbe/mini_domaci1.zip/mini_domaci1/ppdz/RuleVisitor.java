package ppdz;
import ppdz.ast.*;

public class RuleVisitor extends VisitorAdaptor {
    	public void visit(Prog_id prog_id) { 
		System.out.println("Pronadjena glavna klasa: "+prog_id.getId()+" na liniji "+prog_id.getLine()); 
	}

    	public void visit(Assignment assignment) { 
		System.out.println("Pronadjen izraz dodele na liniji "+assignment.getLine());
	}

	public void visit(ProcCallStatement procCallStatement) {
		System.out.println("Pronadjen poziv metode bez argumenata na liniji "+procCallStatement.getLine());
	}

    	public void visit(FuncCallStatement funcCallStatement) {
		System.out.println("Pronadjen poziv metode sa argumentima na liniji "+funcCallStatement.getLine());
	}

    	public void visit(ReturnNoExpr returnNoExpr) {
		System.out.println("Pronadjen prazan return iskaz na liniji "+returnNoExpr.getLine());
	}

    	public void visit(Return ret) {
		System.out.println("Pronadjen return iskaz na liniji "+ret.getLine());
	}

    	public void visit(Print print) {
		System.out.println("Pronadjen poziv metode print na liniji "+print.getLine());
	}

}
