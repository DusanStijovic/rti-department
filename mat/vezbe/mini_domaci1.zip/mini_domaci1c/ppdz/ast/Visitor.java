// generated with ast extension for cup
// version 0.8
// 16/10/2017 13:8:1


package ppdz.ast;

public interface Visitor { 

    public void visit(Rhs rhs);
    public void visit(Statement statement);
    public void visit(Var_list var_list);
    public void visit(Factor_list factor_list);
    public void visit(Local_var_list local_var_list);
    public void visit(Parameter parameter);
    public void visit(Declaration_part declaration_part);
    public void visit(Ident_expr_list ident_expr_list);
    public void visit(Stmt_list stmt_list);
    public void visit(Addop addop);
    public void visit(Declaration_list declaration_list);
    public void visit(Factor factor);
    public void visit(Term_list term_list);
    public void visit(Expr_list expr_list);
    public void visit(Parameter_list parameter_list);
    public void visit(Method_declaration_list method_declaration_list);
    public void visit(Mulop mulop);
    public void visit(Form_pars form_pars);
    public void visit(Return_type_ident return_type_ident);
    public void visit(Var_part var_part);
    public void visit(ParenthesisExpr ParenthesisExpr);
    public void visit(OperatorNew OperatorNew);
    public void visit(CharRef CharRef);
    public void visit(IntRef IntRef);
    public void visit(ArrayRef ArrayRef);
    public void visit(VarRef VarRef);
    public void visit(FuncCall FuncCall);
    public void visit(MinusFactor MinusFactor);
    public void visit(SimpleFactor SimpleFactor);
    public void visit(MulopFactor MulopFactor);
    public void visit(Term Term);
    public void visit(TermExpr TermExpr);
    public void visit(AddExpr AddExpr);
    public void visit(Expr Expr);
    public void visit(Expression Expression);
    public void visit(Expressions Expressions);
    public void visit(Act_pars Act_pars);
    public void visit(DivOp DivOp);
    public void visit(TimesOp TimesOp);
    public void visit(MinusOp MinusOp);
    public void visit(PlusOp PlusOp);
    public void visit(SimpleDesignator SimpleDesignator);
    public void visit(ArrayDesignator ArrayDesignator);
    public void visit(Designator Designator);
    public void visit(StatementDerived1 StatementDerived1);
    public void visit(Print Print);
    public void visit(Return Return);
    public void visit(ReturnNoExpr ReturnNoExpr);
    public void visit(FuncCallStatement FuncCallStatement);
    public void visit(ProcCallStatement ProcCallStatement);
    public void visit(Assignment Assignment);
    public void visit(NoStatements NoStatements);
    public void visit(Statements Statements);
    public void visit(ArrayParameter ArrayParameter);
    public void visit(ScalarParameter ScalarParameter);
    public void visit(FormalParameter FormalParameter);
    public void visit(FormalParameters FormalParameters);
    public void visit(NoFormalParams NoFormalParams);
    public void visit(FormalParams FormalParams);
    public void visit(Method_dec Method_dec);
    public void visit(VoidRetType VoidRetType);
    public void visit(ReturnType ReturnType);
    public void visit(NoMethods NoMethods);
    public void visit(Methods Methods);
    public void visit(NoLocalVars NoLocalVars);
    public void visit(LocalVars LocalVars);
    public void visit(VarArrayId VarArrayId);
    public void visit(VarId VarId);
    public void visit(VarOrArrayId VarOrArrayId);
    public void visit(VarIdList VarIdList);
    public void visit(Var_dec Var_dec);
    public void visit(CharInitializer CharInitializer);
    public void visit(IntInitializer IntInitializer);
    public void visit(Type Type);
    public void visit(Const_dec Const_dec);
    public void visit(VarDeclaration VarDeclaration);
    public void visit(ConstDeclaration ConstDeclaration);
    public void visit(NoDeclarations NoDeclarations);
    public void visit(Declarations Declarations);
    public void visit(Prog_id Prog_id);
    public void visit(Program Program);

}
