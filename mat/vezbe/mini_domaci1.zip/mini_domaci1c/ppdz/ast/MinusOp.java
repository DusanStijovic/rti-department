// generated with ast extension for cup
// version 0.8
// 16/10/2017 13:8:0


package ppdz.ast;

public class MinusOp extends Addop {

    public MinusOp () {
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("MinusOp(\n");

        buffer.append(tab);
        buffer.append(") [MinusOp]");
        return buffer.toString();
    }
}
