// generated with ast extension for cup
// version 0.8
// 16/10/2017 13:8:0


package ppdz.ast;

public class LocalVars extends Local_var_list {

    private Local_var_list local_var_list;
    private Var_dec var_dec;

    public LocalVars (Local_var_list local_var_list, Var_dec var_dec) {
        this.local_var_list=local_var_list;
        if(local_var_list!=null) local_var_list.setParent(this);
        this.var_dec=var_dec;
        if(var_dec!=null) var_dec.setParent(this);
    }

    public Local_var_list getLocal_var_list() {
        return local_var_list;
    }

    public void setLocal_var_list(Local_var_list local_var_list) {
        this.local_var_list=local_var_list;
    }

    public Var_dec getVar_dec() {
        return var_dec;
    }

    public void setVar_dec(Var_dec var_dec) {
        this.var_dec=var_dec;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(local_var_list!=null) local_var_list.accept(visitor);
        if(var_dec!=null) var_dec.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(local_var_list!=null) local_var_list.traverseTopDown(visitor);
        if(var_dec!=null) var_dec.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(local_var_list!=null) local_var_list.traverseBottomUp(visitor);
        if(var_dec!=null) var_dec.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("LocalVars(\n");

        if(local_var_list!=null)
            buffer.append(local_var_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(var_dec!=null)
            buffer.append(var_dec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [LocalVars]");
        return buffer.toString();
    }
}
