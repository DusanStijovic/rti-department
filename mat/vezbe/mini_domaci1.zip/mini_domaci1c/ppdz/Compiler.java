
package ppdz;

import java_cup.runtime.*;
import java.io.*;
import ppdz.ast.*;

class Compiler {
	public static void main(String args[]) throws Exception {
		FileReader r = new FileReader(args[0]);
		Yylex skener = new Yylex(r);
		parser p = new parser(skener);
		Symbol s = p.parse();
        if (p.greska) System.out.println("Ulazni program ima gresaka!");
        else System.out.println("Parsiranje uspesno zavrseno!");

		Program prog = (Program)(s.value);

		// ispis sintaksnog stabla
                System.out.println(prog.toString(""));
		System.out.println("===================================");

		// ispis prepoznatih programskih konstrukcija
		RuleVisitor v = new RuleVisitor(); 
		prog.traverseBottomUp(v);

	}
}
