package ppdz;
import ppdz.ast.*;

public class SymbolTableVisitor extends VisitorAdaptor {


/*****************************************************************
* Sledece promenljive ce biti vidljive iz akcija u svim 
* smenama. var_type sluzi za cuvanje cvora Struct koji 
* odgovara tipu na pocetku deklaracije grupe promenljivih.
* method_type cuva povratni tip tekuceg metoda za semanticke provere  
* kod return. promenljiva returnExists ima vrednost true ako telo metoda ima 
* return iskaz.
*****************************************************************/ 
    private Struct var_type=Tab.noType;
    private Struct method_type=Tab.noType;
    private boolean returnExists=false; 
	
	public boolean greska=false;

	private void report_error(String message) {
      greska=true;
      System.err.println(message);
      System.err.flush();
    }

/*****************************************************************
* obj predstavlja Obj cvor glavne klase. Na kraju analize programa
* se unutrasnji opseg zatvara, a njegovi cvorovi vezuju za
* cvor glavne klase, tj. programa. 
*****************************************************************/ 
	public void visit(Program program) {
		program.getProg_id().obj.locals=Tab.topScope.locals;
		Tab.closeScope();
	}

/*****************************************************************
* Kada prepoznamo glavni program, u tabelu simbola ubacujemo 
* cvor koji mu odgovara i otvaramo novi opseg u koji cemo ubacivati 
* simbole glavnog programa.
*****************************************************************/ 
	public void visit(Prog_id prog_id) {
		prog_id.obj = Tab.insert(Obj.Prog,prog_id.getId(),prog_id.getLine(),Tab.noType);
                Tab.openScope();
	}

/*****************************************************************
* Kada se u obilasku stabla naidje na identifikator tipa,
* neterminalu type se dodeljuje odgovarajuci Struct cvor
* pronadjen prema imenu u tabeli simbola
* Da bi nam i pri obilasku cvorova VarId i VarArrayId bio dostupan
* tip promenljivih koje se deklarisu, sacuvacemo ga u 
* promenljivoj var_type.
*****************************************************************/ 
	public void visit(Type type) { 
		Obj novi=Tab.find(type.getId(), type.getLine());
                if (novi.kind == Obj.Type )
                   var_type = type.struct = novi.type;
                else {
                   report_error("Greska u liniji "+type.getLine()+" ("+type.getId()+") nije tip");
                   var_type = type.struct = Tab.noType;
               }
	}

/*****************************************************************
* Kada u deklaraciji dodjemo do imena pojedinacne promenljive,
* ubacujemo je u tabelu simbola (cak i kada je tip noType, da bismo u
* oporavku izbegli greske nedeklarisane promenljive)
*****************************************************************/ 
	public void visit(VarId varId) { 
		Tab.insert(Obj.Var, varId.getId(), varId.getLine(), var_type); 
	}

	public void visit(VarArrayId varArrayId) {
		Tab.insert(Obj.Var, varArrayId.getId(), varArrayId.getLine(), new Struct(Struct.Arr, var_type));  
	}

	public void visit(ReturnType returnType) {
		method_type = returnType.getType().struct; 
		returnType.obj = Tab.insert( Obj.Meth, returnType.getId(), returnType.getLine(), method_type); 
        Tab.openScope(); 
	}

	public void visit(VoidRetType voidRetType) {
		method_type=Tab.noType; 
		voidRetType.obj = Tab.insert( Obj.Meth, voidRetType.getId(), voidRetType.getLine(), method_type); 
		Tab.openScope();		 
	}

    public void visit(Method_dec_start method_dec_start) {
		if (method_dec_start.getReturn_type_ident().obj.name.equals("main")) {
			if (method_type!=Tab.noType) 
				report_error("Greska u liniji "+method_dec_start.getLine()+": metod main mora biti void");
		}
	}

/*****************************************************************
* Na kraju obrade metoda proveravamo da li se radi o metodu
* koji nije void, a u njegovom telu nema return iskaza. 
* Ako je to slucaj, prijavljuje se greska.
*****************************************************************/ 
	public void visit(Method_dec method_dec) {
		if (method_type!=Tab.noType && !returnExists) { 
			report_error("Greska u liniji "+method_dec.getLine()+": Metod mora imati return iskaz jer nije deklarisan sa void");
		}
        returnExists=false; // inic. vrednost za sledeci metod
		Obj o = method_dec.getMethod_dec_start().getReturn_type_ident().obj;
		o.level=0; 
		o.locals = Tab.topScope.locals; 
		Tab.closeScope();

	}

	public void visit(Assignment assignment) {
		Struct t = assignment.getExpr().struct;
		Obj o = assignment.getDesignator().obj;
		if ( !t.assignableTo(o.type) )
			report_error("Greska u liniji "+assignment.getLine()+": nekompatibilni tipovi za dodelu");
	}

	public void visit(ProcCallStatement procCallStatement) { 
		Obj o = procCallStatement.getDesignator().obj;
		if (o.kind!=Obj.Meth )
			report_error("Greska u liniji "+procCallStatement.getLine()+": Ocekivan metod");

	}

	public void visit(FuncCallStatement funcCallStatement) {
		// obrada stvarnih parametara nije implementirana
		Obj o = funcCallStatement.getDesignator().obj;
		if (o.kind!=Obj.Meth )
			report_error("Greska u liniji "+funcCallStatement.getLine()+": Ocekivan metod");

	}

/*****************************************************************
* Pri prepoznavanju return iskaza postavljamo promenljivu 
* returnExists. Ako metoda koja nije void ima prazan return 
* iskaz, prijavljuje se greska. Ako void metoda ima return 
* iskaz koji vraca vrednost, prijavljuje se greska.
*****************************************************************/
	public void visit(ReturnNoExpr returnNoExpr) { 
	        returnExists=true;
		if (method_type!=Tab.noType) {
			report_error("Greska u liniji "
                         +returnNoExpr.getLine()+": metod mora imati return iskaz sa izrazom jer nije deklarisan sa void");
		}
	}

	public void visit(Return ret) {
	        returnExists=true;
		if (method_type==Tab.noType) {
			report_error("Greska u liniji "+ret.getLine()+": metod ne sme imati return sa izrazom jer je deklarisan sa void");
		}
		Struct t = ret.getExpr().struct;
	    if (!t.assignableTo(method_type))
			report_error("Greska u liniji "+ret.getLine()+": tip izraza nekompatibilan sa deklaracijom metoda");

	}

    public void visit(Print print) { 
		Struct t = print.getExpr().struct;
		if (t != Tab.intType && t!=Tab.charType ) 
			report_error("Greska u liniji "+print.getLine()+": tip izraza mora biti int ili char");
		
	}

    public void visit(Designator designator) {
		designator.obj = designator.getIdent_expr_list().obj;
	}

/*****************************************************************
* Kada u telu metode detektujemo koriscenje nekog imena, 
* upotrebom metode find, proveravamo da li se objekat koji 
* odgovara tom imenu nalazi u tabeli simbola. Ako se ne nalazi
* prijavljujemo gresku. Ako se radi o koriscenju niza, moramo 
* proveriti i da li je objekat u tabeli simbola tipa niza.
*****************************************************************/ 
	public void visit(ArrayDesignator arrayDesignator) {
		Obj id = arrayDesignator.getIdent_expr_list_lsquare().obj;
		if (id.type.kind!=Struct.Arr) {
            report_error("Greska u liniji "+arrayDesignator.getLine()+": Ocekivan niz");
			arrayDesignator.obj = id;	
		}
		else {
			// dalje prenosimo element niza
			arrayDesignator.obj = new Obj(Obj.Elem, "", id.type.elemType);
		}
	}

	public void visit(SimpleDesignator simpleDesignator) {
		Obj ob=Tab.find(simpleDesignator.getId(), simpleDesignator.getLine()); // find prijavljuje gresku u slucaju da ne nadje
                if (ob != Tab.noObj) {
                         System.out.println("Pretraga "+simpleDesignator.getLine()+" ("+simpleDesignator.getId()+"), nadjeno "+ob);
		} 
        simpleDesignator.obj = ob;
	}

	public void visit(Ident_expr_list_lsquare ident_expr_list_lsquare) {
		ident_expr_list_lsquare.obj = ident_expr_list_lsquare.getIdent_expr_list().obj;
	}
	
    public void visit(Expr expr) {
		expr.struct = expr.getTerm_list().struct;
	}
	
	public void visit(AddExpr addExpr) {
		// nije implementirano
        addExpr.struct=Tab.noType;
	}

	public void visit(TermExpr termExpr) {
        termExpr.struct=termExpr.getTerm().struct;
	}

	public void visit(Term term) {
        term.struct=term.getFactor_list().struct;
	}

	public void visit(MulopFactor mulopFactor) {
		// nije implementirano
        mulopFactor.struct=Tab.noType;
	}

	public void visit(SimpleFactor simpleFactor) {
        simpleFactor.struct=simpleFactor.getFactor().struct;
	}

	public void visit(MinusFactor minusFactor) {
		// nije implementirano
        minusFactor.struct=Tab.noType;
	}

    public void visit(FuncCall funcCall) {
		// obrada stvarnih parametara nije implementirana
		Obj o = funcCall.getDesignator().obj;
        if (o.kind!=Obj.Meth )
            report_error("Greska u liniji "+funcCall.getLine()+": Ocekivan metod");
        if (o.type==Tab.noType )
            report_error("Greska u liniji "+funcCall.getLine()+": Procedura pozvana kao funkcija");
        funcCall.struct=o.type;	
	}
	
	public void visit(VarRef varRef) {
		Obj o = varRef.getDesignator().obj;
		if ( o.kind!=Obj.Var && o.kind!=Obj.Elem )
            report_error("Greska u liniji "+varRef.getLine()+": Ocekivana promenljiva ili element niza");
        varRef.struct=o.type;
	}

	// ovde je ime klase pogresno izabrano, nije upotreba niza vec poziv funkcije bez parametara
    public void visit(ArrayRef funcCall) {
		// obrada stvarnih parametara nije implementirana
		Obj o = funcCall.getDesignator().obj;
        if (o.kind!=Obj.Meth )
            report_error("Greska u liniji "+funcCall.getLine()+": Ocekivan metod");
        if (o.type==Tab.noType )
            report_error("Greska u liniji "+funcCall.getLine()+": Procedura pozvana kao funkcija");
        funcCall.struct=o.type;	
	}
	
	public void visit(IntRef intRef) {
        intRef.struct=Tab.intType;		
	}

	public void visit(CharRef charRef) {
        charRef.struct=Tab.charType;		
	}

    public void visit(OperatorNew operatorNew) {
		if ( operatorNew.getExpr().struct != Tab.intType)
			report_error("Greska u liniji "+operatorNew.getLine()+": velicina niza mora biti tipa int");
        operatorNew.struct=new Struct(Struct.Arr, operatorNew.getType().struct);		
	}
	
	public void visit(ParenthesisExpr parenthesisExpr) {
		parenthesisExpr.struct = parenthesisExpr.getExpr().struct;
	}
}

