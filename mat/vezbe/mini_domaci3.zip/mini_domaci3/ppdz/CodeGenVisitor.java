package ppdz;
import ppdz.ast.*;

public class CodeGenVisitor extends VisitorAdaptor {

/*****************************************************************
*  Vraca broj elemenata u listi Obj cvorova
*****************************************************************/ 	
	public int nVars(Obj o) {
		int n = 0;
		for (;o != null; n++)
			o = o.next;
		return n;
	}

/*****************************************************************
* obj predstavlja Obj cvor glavne klase. Koristimo podatak o velicini
* staticke oblasti, izracunat u semantickoj analizi
*****************************************************************/ 	
	public void visit(Program program) {
		Code.dataSize=nVars(program.getProg_id().obj.locals);
	}

    public void visit(Method_dec_start method_dec_start) {
		if (method_dec_start.getReturn_type_ident().obj.name.equals("main")) {
			Code.mainPc = Code.pc;
		}
		Obj o = method_dec_start.getReturn_type_ident().obj; // Obj cvor zapamcen tokom sint. analize
        o.adr = Code.pc;
        Code.put(Code.enter);
        Code.put(o.level);
        Code.put(nVars(o.locals)); // velicina locals liste metoda
	}

/*****************************************************************
* Na kraju tela metoda generisemo sekvencu povratka
* za proceduru, kojoj nije neophodan return iskaz, a trap 
* inistrukciju za funkciju koja bi morala da izvrsi return, za
* slucaj da ga nema u kodu ili je zaobidjen tokom izvrsavanja programa
*****************************************************************/ 
	public void visit(Method_dec method_dec) {
		Obj o = method_dec.getMethod_dec_start().getReturn_type_ident().obj;
		Struct method_type = o.type;
		// generisanje koda
		if (method_type==Tab.noType) {
			Code.put(Code.exit); 
			Code.put(Code.return_);
		} else { // end of function reached without a return statement
			Code.put(Code.trap); 
			Code.put(1);
		}
	}

	public void visit(Assignment assignment) {
		Code.store(assignment.getDesignator().obj);
	}
	
	public void visit(ProcCallStatement procCallStatement) { 
		Obj o = procCallStatement.getDesignator().obj;
		int dest_adr=o.adr-Code.pc; // racunanje relativne adrese 
		Code.put(Code.call); 
		Code.put2(dest_adr);
		if (o.type!=Tab.noType )
			Code.put(Code.pop); // rezultat poziva nece biti koriscen
	}

	public void visit(FuncCallStatement funcCallStatement) { 
		Obj o = funcCallStatement.getDesignator().obj;
		int dest_adr=o.adr-Code.pc; // racunanje relativne adrese 
		Code.put(Code.call); 
		Code.put2(dest_adr);
		if (o.type!=Tab.noType )
			Code.put(Code.pop); // rezultat poziva nece biti koriscen
	}

	public void visit(ReturnNoExpr returnNoExpr) { 
		Code.put(Code.exit);
		Code.put(Code.return_);
	}

	public void visit(Return ret) { 
		Code.put(Code.exit);
		Code.put(Code.return_);
	}

	public void visit(Print print) { 
		Struct t = print.getExpr().struct;
		if (t == Tab.intType) {
			Code.loadConst(5); // sirina ispisa na e-stek, expr je vec na e-steku
			Code.put(Code.print);
		} else {
			Code.loadConst(1); // sirina ispisa na e-stek, expr je vec na e-steku
			Code.put(Code.bprint);
		}		
	}

	public void visit(Ident_expr_list_lsquare ident_expr_list_lsquare) {
		Obj o = ident_expr_list_lsquare.getIdent_expr_list().obj;
		Code.load(o);
	}
	
    public void visit(Expressions expressions) {
		Code.put(Code.pop); // stvarni parametri nisu implementirani, pa da ne ostanu na steku
	}

    public void visit(Expression expression) {
		Code.put(Code.pop); // stvarni parametri nisu implementirani, pa da ne ostanu na steku
	}

    public void visit(FuncCall funcCall) {
		// obrada stvarnih parametara nije implementirana
		Obj o = funcCall.getDesignator().obj;
        int dest_adr=o.adr-Code.pc; // racunanje relativne adrese 
        Code.put(Code.call); 
        Code.put2(dest_adr);
	}

	public void visit(VarRef varRef) {
		Obj o = varRef.getDesignator().obj;
        Code.load(o);
	}

// ovde je ime klase pogresno izabrano, nije upotreba niza vec poziv funkcije bez parametara
    public void visit(ArrayRef funcCall) {
		// obrada stvarnih parametara nije implementirana
		Obj o = funcCall.getDesignator().obj;
        int dest_adr=o.adr-Code.pc; // racunanje relativne adrese 
        Code.put(Code.call); 
        Code.put2(dest_adr);
	}

	public void visit(IntRef intRef) {
		Obj o = new Obj(Obj.Con, "", Tab.intType);
        o.adr=intRef.getI(); 
		Code.load(o); 
	}

	public void visit(CharRef charRef) {
		Obj o = new Obj(Obj.Con, "", Tab.charType);
        o.adr=charRef.getC(); 
		Code.load(o); 
	}

    public void visit(OperatorNew operatorNew) {
        Code.put(Code.newarray);
        if ( operatorNew.getType().struct == Tab.charType ) 
			Code.put(0); 
        else 
			Code.put(1);
	}
}