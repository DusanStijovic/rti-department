// generated with ast extension for cup
// version 0.8
// 16/10/2017 11:59:43


package ppdz.ast;

public class Method_dec implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    private Method_dec_start method_dec_start;
    private Stmt_list stmt_list;

    public Method_dec (Method_dec_start method_dec_start, Stmt_list stmt_list) {
        this.method_dec_start=method_dec_start;
        if(method_dec_start!=null) method_dec_start.setParent(this);
        this.stmt_list=stmt_list;
        if(stmt_list!=null) stmt_list.setParent(this);
    }

    public Method_dec_start getMethod_dec_start() {
        return method_dec_start;
    }

    public void setMethod_dec_start(Method_dec_start method_dec_start) {
        this.method_dec_start=method_dec_start;
    }

    public Stmt_list getStmt_list() {
        return stmt_list;
    }

    public void setStmt_list(Stmt_list stmt_list) {
        this.stmt_list=stmt_list;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(method_dec_start!=null) method_dec_start.accept(visitor);
        if(stmt_list!=null) stmt_list.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(method_dec_start!=null) method_dec_start.traverseTopDown(visitor);
        if(stmt_list!=null) stmt_list.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(method_dec_start!=null) method_dec_start.traverseBottomUp(visitor);
        if(stmt_list!=null) stmt_list.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Method_dec(\n");

        if(method_dec_start!=null)
            buffer.append(method_dec_start.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(stmt_list!=null)
            buffer.append(stmt_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Method_dec]");
        return buffer.toString();
    }
}
