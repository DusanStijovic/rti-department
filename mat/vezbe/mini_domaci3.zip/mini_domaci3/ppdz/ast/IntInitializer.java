// generated with ast extension for cup
// version 0.8
// 16/10/2017 11:59:43


package ppdz.ast;

public class IntInitializer extends Rhs {

    private int N1;

    public IntInitializer (int N1) {
        this.N1=N1;
    }

    public int getN1() {
        return N1;
    }

    public void setN1(int N1) {
        this.N1=N1;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("IntInitializer(\n");

        buffer.append(" "+tab+N1);
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [IntInitializer]");
        return buffer.toString();
    }
}
