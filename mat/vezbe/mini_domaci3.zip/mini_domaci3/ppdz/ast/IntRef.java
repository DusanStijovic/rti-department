// generated with ast extension for cup
// version 0.8
// 16/10/2017 11:59:44


package ppdz.ast;

public class IntRef extends Factor {

    private int i;

    public IntRef (int i) {
        this.i=i;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i=i;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("IntRef(\n");

        buffer.append(" "+tab+i);
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [IntRef]");
        return buffer.toString();
    }
}
