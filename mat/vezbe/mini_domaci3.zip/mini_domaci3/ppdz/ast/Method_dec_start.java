// generated with ast extension for cup
// version 0.8
// 16/10/2017 11:59:43


package ppdz.ast;

public class Method_dec_start implements SyntaxNode {

    private SyntaxNode parent;
    private int line;
    public ppdz.Obj obj = null;

    private Return_type_ident return_type_ident;
    private Form_pars form_pars;
    private Local_var_list local_var_list;

    public Method_dec_start (Return_type_ident return_type_ident, Form_pars form_pars, Local_var_list local_var_list) {
        this.return_type_ident=return_type_ident;
        if(return_type_ident!=null) return_type_ident.setParent(this);
        this.form_pars=form_pars;
        if(form_pars!=null) form_pars.setParent(this);
        this.local_var_list=local_var_list;
        if(local_var_list!=null) local_var_list.setParent(this);
    }

    public Return_type_ident getReturn_type_ident() {
        return return_type_ident;
    }

    public void setReturn_type_ident(Return_type_ident return_type_ident) {
        this.return_type_ident=return_type_ident;
    }

    public Form_pars getForm_pars() {
        return form_pars;
    }

    public void setForm_pars(Form_pars form_pars) {
        this.form_pars=form_pars;
    }

    public Local_var_list getLocal_var_list() {
        return local_var_list;
    }

    public void setLocal_var_list(Local_var_list local_var_list) {
        this.local_var_list=local_var_list;
    }

    public SyntaxNode getParent() {
        return parent;
    }

    public void setParent(SyntaxNode parent) {
        this.parent=parent;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line=line;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(return_type_ident!=null) return_type_ident.accept(visitor);
        if(form_pars!=null) form_pars.accept(visitor);
        if(local_var_list!=null) local_var_list.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(return_type_ident!=null) return_type_ident.traverseTopDown(visitor);
        if(form_pars!=null) form_pars.traverseTopDown(visitor);
        if(local_var_list!=null) local_var_list.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(return_type_ident!=null) return_type_ident.traverseBottomUp(visitor);
        if(form_pars!=null) form_pars.traverseBottomUp(visitor);
        if(local_var_list!=null) local_var_list.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Method_dec_start(\n");

        if(return_type_ident!=null)
            buffer.append(return_type_ident.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(form_pars!=null)
            buffer.append(form_pars.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(local_var_list!=null)
            buffer.append(local_var_list.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Method_dec_start]");
        return buffer.toString();
    }
}
