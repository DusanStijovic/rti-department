// generated with ast extension for cup
// version 0.8
// 16/10/2017 11:59:44


package ppdz.ast;

public class ArrayDesignator extends Ident_expr_list {

    private Ident_expr_list_lsquare ident_expr_list_lsquare;
    private Expr expr;

    public ArrayDesignator (Ident_expr_list_lsquare ident_expr_list_lsquare, Expr expr) {
        this.ident_expr_list_lsquare=ident_expr_list_lsquare;
        if(ident_expr_list_lsquare!=null) ident_expr_list_lsquare.setParent(this);
        this.expr=expr;
        if(expr!=null) expr.setParent(this);
    }

    public Ident_expr_list_lsquare getIdent_expr_list_lsquare() {
        return ident_expr_list_lsquare;
    }

    public void setIdent_expr_list_lsquare(Ident_expr_list_lsquare ident_expr_list_lsquare) {
        this.ident_expr_list_lsquare=ident_expr_list_lsquare;
    }

    public Expr getExpr() {
        return expr;
    }

    public void setExpr(Expr expr) {
        this.expr=expr;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ident_expr_list_lsquare!=null) ident_expr_list_lsquare.accept(visitor);
        if(expr!=null) expr.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ident_expr_list_lsquare!=null) ident_expr_list_lsquare.traverseTopDown(visitor);
        if(expr!=null) expr.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ident_expr_list_lsquare!=null) ident_expr_list_lsquare.traverseBottomUp(visitor);
        if(expr!=null) expr.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ArrayDesignator(\n");

        if(ident_expr_list_lsquare!=null)
            buffer.append(ident_expr_list_lsquare.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(expr!=null)
            buffer.append(expr.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ArrayDesignator]");
        return buffer.toString();
    }
}
