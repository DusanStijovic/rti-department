
package ppdz;

import java_cup.runtime.*;
import java.io.*;
import ppdz.ast.*;

class Compiler {
	public static void main(String args[]) throws Exception {
    	FileReader r=null;
   		try {
			r = new FileReader(args[0]);
   		} catch(Exception e) {
   		    System.err.println("Greska pri otvaranju ulaznog fajla");
   		    System.exit(1);
   		}
   		Yylex skener = new Yylex(r);
   		parser p = new parser(skener);
		Symbol s = p.parse();
		//System.out.println(s.value.getClass());
		Program prog = (Program)(s.value);
        /******************************************************************
        * Staticka metoda init tabele simbola sluzi za pocetno pravljenje 
        * tabele simbola, odnosno "universe" opsega.
        ******************************************************************/
    	Tab.init();
		SymbolTableVisitor stv = new SymbolTableVisitor(); 
		prog.traverseBottomUp(stv);
        /*****************************************************************
        * Po zavrsetku analize, pozivom metode dump(), vrsimo ispis 
        * sadrzaja tabele simbola.
        *****************************************************************/ 
		Tab.dump();
		//System.out.println(prog.toString(""));
        /*****************************************************************
        * Generisanje koda
        *****************************************************************/ 		
		CodeGenVisitor cg = new CodeGenVisitor(); 
		prog.traverseBottomUp(cg);

		try {
    	   if ( !p.greska && !Tab.greska && !stv.greska && !Code.greska ) 
    		      Code.write(new FileOutputStream(args[1]));
    	} catch(Exception e) {
    	    System.err.println("Greska pri kreiranju objektnog fajla");
    	}
	}
}
