import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-azuriraj-obavestenje',
  templateUrl: './azuriraj-obavestenje.component.html',
  styleUrls: ['./azuriraj-obavestenje.component.css']
})
export class AzurirajObavestenjeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
