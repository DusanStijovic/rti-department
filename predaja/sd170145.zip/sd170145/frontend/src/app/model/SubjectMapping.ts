export default class SubjectMapping {
    subject_id: string;
    department: string;
    mapped_subject_id: string;
}
