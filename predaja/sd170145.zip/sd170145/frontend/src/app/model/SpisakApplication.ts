export default class SpisakApplication {
    studentID: string;
    spisakID: string;
    subjectID: string;
    materialLink: string;
}