

export const enum UserType {
    None, Student, Admin, Employee
}
