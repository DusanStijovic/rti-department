export class BasicInfoSubject {
    name: string;
    id: string;
    _id: string;
    link_id: string;
}