export default class EmployeeProject {
    title: string;
    description: string;
    readMore: string;
    authors: string[];
};