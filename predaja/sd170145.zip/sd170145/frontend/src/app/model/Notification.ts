export default class Notification {
        title : String;
        content: String;
        dateCreation: Date;
        readMore: string; 
        notificationType: string;
}