export default class SubjectMaterialsInfo {
    name: string;
    link: string;
    format: string;
    number: number;
    _id: string;
    size: number;
    employee: string;
    date: Date;
}