import OneProject from "./OneProject";

export default class SubjectProject{
    isHidden: boolean;
    info: String;
    projects : OneProject[];
   
}