export default class SubjectNotifications {
    _id: string;
    title: string;
    dateCreation: Date;
    content: string;
    materials: string[];
    connectedSubject: string[];
} 