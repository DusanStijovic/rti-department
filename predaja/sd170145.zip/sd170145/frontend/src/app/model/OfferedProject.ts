export default class OfferedProject {
    title: string;
    type: string;
    description:string;
    readMore:string;
}; 