import SubjectMaterialsInfo from "./SubjectMaterialsInfo";

export default class OneProject {
    info: string;
    examinationProcess: string;
    materials: SubjectMaterialsInfo[];
    _id: string
    
}