import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-autorized-access',
  templateUrl: './not-autorized-access.component.html',
  styleUrls: ['./not-autorized-access.component.css']
})
export class NotAutorizedAccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
