import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser'
import mongoose from 'mongoose'
import knjiga from './model/knjiga';
import narudzbina from './model/narudzbina';

const app = express();

app.use(cors());
app.use(bodyParser.json())

mongoose.connect("mongodb://localhost:27017/knjizaraperce");

const conn = mongoose.connection;

conn.once('open',()=>{
    console.log('Uspesna konekcija');
});

const router = express.Router();

router.route('/dohvatiSveKnjige').get((req, res)=>{
    knjiga.find({}, (err, knjige)=>{
        if(err) console.log(err);
        else res.json(knjige);
    })
});

router.route('/naruci').post((req, res)=>{
    let idK = req.body.idK;
    let kolicina = req.body.kolicina;

    knjiga.findOne({'idK':idK, 'naStanju': {$gte: kolicina}}, (err, knjiga)=>{
        if(err) console.log(err);
        else{
            if(knjiga){
                let nar = {
                    knjiga: idK,
                    kolicina: kolicina,
                    status: 'naruceno'
                }
                narudzbina.collection.updateOne({"id":1}, {$push: {"narudzbine": nar}});
                knjiga.collection.updateOne({"idK": idK}, {$inc: {'naStanju':-kolicina}});
                res.json({'poruka': 'OK'});
            }
            else{
                res.json({'poruka': 'Nema na stanju'});
            }
        }
    })
})

router.route('/dohvatiSveNarudzbine').get((req, res)=>{
    narudzbina.find({}, (err, narudzbine)=>{
        if(err) console.log(err);
        else res.json(narudzbine[0]); 
        //imamo samo jedan objekat za sve narudzbine, i u njemu je niz drugih narudzbina
        //pa je zato dovoljno vratiti samo taj jedan objekat [0]
        //moglo je i findOne po id
    })
})

router.route('/dohvatiKnjigu').post((req, res)=>{
    let idK = req.body.idK;

    knjiga.findOne({"idK":idK}, (err, knjiga)=>{
        if(err) console.log(err);
        else res.json(knjiga);
    })
})

router.route('/prihvatiNarudzbinu').post((req, res)=>{
    let pozicija = 'narudzbine.'+req.body.indexNarudzbine+'.status';
    //kreiram string koji ce za drugi element u nizu narudzbina izgledati
    //narudzbine.1.status
    //i tom elementu menjam status

    narudzbina.collection.updateOne({"id":1}, {$set: {[pozicija]: "prihvaceno"}});
    res.json({'poruka': 'OK'});
})



app.use('/', router);
app.listen(4000, () => console.log(`Express server running on port 4000`));