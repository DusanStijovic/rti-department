export class Narudzbine{
    id: number;
    narudzbine: Array<Object>;
}