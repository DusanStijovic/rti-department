import { Component, OnInit } from '@angular/core';
import { Knjiga } from '../model/knjiga.model';
import { ServisService } from '../servis.service';

@Component({
  selector: 'app-info-knjiga',
  templateUrl: './info-knjiga.component.html',
  styleUrls: ['./info-knjiga.component.css']
})
export class InfoKnjigaComponent implements OnInit {

  constructor(private servis: ServisService) { }

  ngOnInit(): void {
    this.knjiga = JSON.parse(localStorage.getItem('knjiga'));
  }

  knjiga: Knjiga;
  kolicina: string;

  poruka: string;

  naruci(){
    this.servis.naruci(this.knjiga.idK,  this.kolicina).subscribe((resp)=>{
      if(resp['poruka']=="OK"){
        this.poruka='OK';
      }
      else{
        this.poruka = 'Greska pri narucivanju';
      }
    })
  }

}
