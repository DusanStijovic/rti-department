export class Narudzbina{
    knjiga: number;
    kolicina: number;
    status: string;
    naziv: string;
}