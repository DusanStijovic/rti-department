import { Component, OnInit } from '@angular/core';
import { Narudzbina } from '../model/narudzbina.model';
import { Narudzbine } from '../model/narudzbine.model';
import { ServisService } from '../servis.service';

@Component({
  selector: 'app-radnik',
  templateUrl: './radnik.component.html',
  styleUrls: ['./radnik.component.css']
})
export class RadnikComponent implements OnInit {

  constructor(private servis: ServisService) { }

  ngOnInit(): void {
    this.servis.dohvatiSveNarudzbine().subscribe((sveNarudzbine: Narudzbine)=>{
      this.narudzbine = sveNarudzbine;
      this.narudzbine.narudzbine.forEach((narudzbina: Narudzbina)=>{
        this.servis.dohvatiKnjigu(narudzbina.knjiga).subscribe((knjiga)=>{
          narudzbina.naziv=knjiga['naslov'];
        })
      })
    })
  }

  narudzbine: Narudzbine;
  poruka: string;

  prihvati(indexNarudzbine){
    this.servis.prihvatiNarudzbinu(indexNarudzbine).subscribe((resp)=>{
      if(resp['poruka']=="OK"){
        this.poruka = "OK";
        this.ngOnInit();
      }
    })
  }

}
