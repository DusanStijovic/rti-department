import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Knjiga } from '../model/knjiga.model';
import { ServisService } from '../servis.service';

@Component({
  selector: 'app-kupac',
  templateUrl: './kupac.component.html',
  styleUrls: ['./kupac.component.css']
})
export class KupacComponent implements OnInit {

  constructor(private servis: ServisService, private ruter: Router) { }

  ngOnInit(): void {
    this.servis.dohvatiSveKnjige().subscribe((knjige: Knjiga[])=>{
      this.sveKnjige = knjige;
    })
  }

  sveKnjige: Knjiga[]

  kupi(knjiga: Knjiga){
    localStorage.setItem('knjiga', JSON.stringify(knjiga));
    this.ruter.navigate(['infoKnjiga'])
  }

}
