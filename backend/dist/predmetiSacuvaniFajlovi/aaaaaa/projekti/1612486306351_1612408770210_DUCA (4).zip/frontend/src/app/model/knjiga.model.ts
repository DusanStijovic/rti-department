export class Knjiga{
    idK: number;
    naslov: string;
    slika: string;
    autor: string;
    brStr: number;
    godina: number;
    naStanju: number;
}